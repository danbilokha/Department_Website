var __wpo = {
  "assets": {
    "main": [
      "/38329b2422eddb0638cfd14d944e27cc.png",
      "/027466e420bc4c3250313117670fb880.png",
      "/41f5a6115f7a19c67bd8396df3f35607.jpg",
      "/c907e0698006d32a45c2af7af1f2296f.png",
      "/17e771debb757855fb5b07370f035cf6.png",
      "/81e25613f0e0c85ce8bf6753c73a5ec8.png",
      "/dc48f12150225a2e9569f544f5477617.png",
      "/6ff2b6a4e4a13120d34da004c4e78b71.jpg",
      "/335f63e3de9d001cd27cccd7c8e3fccf.png",
      "/05d62eab102be3664b5956d3355f1410.png",
      "/892da62d6327c4897d09af1eb392facc.png",
      "/fb931a873104cfb9e2b5bcb822d63307.png",
      "/d1e25d6be070b892ed671f0c015fb8fe.png",
      "/54514a8028275af971fd6d4c3745df99.png",
      "/edf5067f869d395fa7a6adb3cb6985ac.gif",
      "/602356fd2f76528aaa0435ac03d0b080.png",
      "/ff16f8f069634a22c996a9f78972dfa0.png",
      "/9b10f878c9926238009bf7196336b012.png",
      "/ea7d210480002e571a930aa563bb10af.png",
      "/c559c933307c4f342ee24bfb187bc425.png",
      "/cb23fc9b359a78e79ab8bdabebe5c296.png",
      "/7ce519da839d5216a6c3440cd8bd1db6.png",
      "/bc5c4fe62484de37e0a6d6c86f857c84.png",
      "/6f93a62ddd25e5ed4a4d640d883f9812.png",
      "/favicon.ico",
      "/b2d66d54d1e17f4eb95449fc5f023703.png",
      "/6cb26b069c511fa308a677790460b322.png",
      "/50313d37d567100c1b98cde71715508e.png",
      "/c28dfc2be43fd444b381e62987b55444.png",
      "/3879993b2b1091ea178ca9721431b5f7.png",
      "/749155b7287c2d5f55e7692c68ba0f55.png",
      "/f6ea860e0099aabff865a31960bc1013.png",
      "/da85cfaa356cf3104483e07da09c2583.png",
      "/da284c81e85cc996103ae7491246a242.png",
      "/de5845bf9bba8fce5483f2c493ee68d7.png",
      "/54c7cedd2edbf78c757af70604f27464.png",
      "/cc5f96726b673e59b0b768aa23213e54.png",
      "/4ef547b5401a3cab8108f522ec86eb37.png",
      "/runtime.00ea1d32e658d9d24a16.js",
      "/"
    ],
    "additional": [
      "/0.eab04d484d5ef6d08a12.chunk.js",
      "/1.bc6204cd3e7af36f52aa.chunk.js",
      "/npm.intl.80df8380a1765d8e711e.chunk.js",
      "/npm.redux-saga.4120a3af07f0eb061d35.chunk.js",
      "/npm.webpack.930eb35737a1d76dd1dc.chunk.js",
      "/main.5e027703e99a5adffef8.chunk.js",
      "/npm.babel.cbd622b2e6a0ad546b0f.chunk.js",
      "/npm.connected-react-router.4c4f072dc44cd33b1292.chunk.js",
      "/npm.intl-messageformat.ef4553732cb09ea7cdfb.chunk.js",
      "/npm.intl-relativeformat.1bebde40ba29c84dc892.chunk.js",
      "/npm.lodash.236696cb50af5a5ffcfd.chunk.js",
      "/npm.react-app-polyfill.d83cf03d7d0271d66d4d.chunk.js",
      "/npm.react-intl.09fde717d9b253bae879.chunk.js",
      "/npm.react-redux.10b7364a3b0289a2c902.chunk.js",
      "/15.e6e33ae3bb337cc020d1.chunk.js",
      "/16.0c33da6002ed97f0df45.chunk.js",
      "/17.bfd4b8fad461c2b9f933.chunk.js",
      "/18.450f63017db666d0d6d2.chunk.js",
      "/19.11d29128fb018e743b16.chunk.js",
      "/20.aa1c29a2208f16af229a.chunk.js",
      "/21.2c568ec78d475f527827.chunk.js",
      "/22.c841278654d03d8f13f2.chunk.js",
      "/23.ec45ba762ebe8ac3cfd0.chunk.js",
      "/24.d97a13a928829c0e41aa.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "417aeae0a62d9374c16a9902f98ca340eeb24244": "/38329b2422eddb0638cfd14d944e27cc.png",
    "08c9116fcdb26c95b3989866d5c7280d41e55097": "/027466e420bc4c3250313117670fb880.png",
    "1059e76c40a09586c97f599339af981fc2bf38ee": "/41f5a6115f7a19c67bd8396df3f35607.jpg",
    "dff18fd9fe4503b69b9406b61d1df94cbcc945f3": "/c907e0698006d32a45c2af7af1f2296f.png",
    "fa4c6d00a3e993aff08ae50729bff3a1914fba79": "/17e771debb757855fb5b07370f035cf6.png",
    "609c3175a293ab3261c0b46ae4cb4fc3a5b4ce50": "/81e25613f0e0c85ce8bf6753c73a5ec8.png",
    "67823349766479eb9670e15879662f84dbaef0c7": "/dc48f12150225a2e9569f544f5477617.png",
    "eaa9581479bc6af3bfc0286bc025e61d2db015b3": "/6ff2b6a4e4a13120d34da004c4e78b71.jpg",
    "a23cfd1c178ddb1d61fd713f7a0a84232411f92b": "/335f63e3de9d001cd27cccd7c8e3fccf.png",
    "fd8d320121d7f35f13fd7052367b6dd787d54550": "/05d62eab102be3664b5956d3355f1410.png",
    "5aa16c1b465936ac0ae3714eb8cb26f54c5ac138": "/892da62d6327c4897d09af1eb392facc.png",
    "ae3a3b1bff2bb9eb59ed3d604ec4fe124d052e61": "/fb931a873104cfb9e2b5bcb822d63307.png",
    "1fe9206da8156d302730cd03a37ac226e673a385": "/d1e25d6be070b892ed671f0c015fb8fe.png",
    "14c08a22b376927b4fc7385ea7802eb2db40e0e9": "/54514a8028275af971fd6d4c3745df99.png",
    "95a12f9467eae227ea2e9348645247268a300f8c": "/edf5067f869d395fa7a6adb3cb6985ac.gif",
    "40919c560df6ab9b77dc19584cc2d0bb53829215": "/602356fd2f76528aaa0435ac03d0b080.png",
    "1f51fa438a25ea28de83759f0e5395dfd5ddc434": "/ff16f8f069634a22c996a9f78972dfa0.png",
    "5d927e920eda706be19b2ae5f4a60a5f6564f2a1": "/9b10f878c9926238009bf7196336b012.png",
    "5a29e3b801f67fbaf52d8bb2dd2201c36728b637": "/ea7d210480002e571a930aa563bb10af.png",
    "9d5477c6e353d8b8f23fd558fb67d88256117c55": "/c559c933307c4f342ee24bfb187bc425.png",
    "8b288f32d7f227f35bdccd3c08727fa2f352d5f9": "/cb23fc9b359a78e79ab8bdabebe5c296.png",
    "cfe18fe344a4c7255025eebcf838ac747ebdaaa3": "/7ce519da839d5216a6c3440cd8bd1db6.png",
    "7086503007065dbb559323941761142759f6d5ad": "/bc5c4fe62484de37e0a6d6c86f857c84.png",
    "7b87feee7570542eec976a94673cac89c83c7f57": "/6f93a62ddd25e5ed4a4d640d883f9812.png",
    "5e53ef208f3fa79a48f8374488f473c76e1233de": "/favicon.ico",
    "13643c642fc5c8d740d267137abd02134510e4d8": "/b2d66d54d1e17f4eb95449fc5f023703.png",
    "65b07ead71c473f30bc23a5069e6d19bf91a665a": "/6cb26b069c511fa308a677790460b322.png",
    "a9d7e9f305d4fed31456dfd1a948406f3900ae64": "/50313d37d567100c1b98cde71715508e.png",
    "3d74292f35a3e20f4b66d1f10d4392bf1ee41237": "/c28dfc2be43fd444b381e62987b55444.png",
    "d20e7f48d7112e10858874e7183e7166ec9f475d": "/3879993b2b1091ea178ca9721431b5f7.png",
    "97586941086a0699f320cb036bab2e146c7e647b": "/749155b7287c2d5f55e7692c68ba0f55.png",
    "0291390bbecf6df4ab3e208609da22d6b0669d0e": "/f6ea860e0099aabff865a31960bc1013.png",
    "3df29774f86ec923d98e5a33983aec769e3ba90f": "/da85cfaa356cf3104483e07da09c2583.png",
    "2b891ac0b1ca0b05b033a99e2b118f41db915ee9": "/da284c81e85cc996103ae7491246a242.png",
    "fff1f92057d678513570f5f5ce6b04d1bf854b98": "/de5845bf9bba8fce5483f2c493ee68d7.png",
    "cb5a76cad48dee5a099e5779131c40ba29a62f62": "/54c7cedd2edbf78c757af70604f27464.png",
    "b7e8d9b5d6b38c8ad3073752bf549420dd341feb": "/cc5f96726b673e59b0b768aa23213e54.png",
    "d4d348f0fdab1eb96c405dab1fe71f0337751f52": "/4ef547b5401a3cab8108f522ec86eb37.png",
    "53b86dfe995aba7aafd8038f14843a32dc07397e": "/0.eab04d484d5ef6d08a12.chunk.js",
    "b69a711e6203f1f0bb54180c4ae6f24f9c4e0495": "/1.bc6204cd3e7af36f52aa.chunk.js",
    "e71fc0d103379d28a3f16a83526273818279628f": "/npm.intl.80df8380a1765d8e711e.chunk.js",
    "bc46e846890f6ee18aaf4f6a017f78fceb97ab66": "/npm.redux-saga.4120a3af07f0eb061d35.chunk.js",
    "60100b24ad6aab714b77676b831d6275085c8355": "/npm.webpack.930eb35737a1d76dd1dc.chunk.js",
    "81e6494650deecaf8c1f9f77bcc504d9f4c13418": "/main.5e027703e99a5adffef8.chunk.js",
    "a4dbe829bf0ba3f39c0bdcd4989bad8dc87da714": "/npm.babel.cbd622b2e6a0ad546b0f.chunk.js",
    "331c9621ba80bfb485560bced5fd1aff647c03dd": "/npm.connected-react-router.4c4f072dc44cd33b1292.chunk.js",
    "c7bd9d7dae0a7f2c4ddfe0e90721e396f9467b0c": "/npm.intl-messageformat.ef4553732cb09ea7cdfb.chunk.js",
    "fc2902009fbe14cdd778b117f14f672c409de8cc": "/npm.intl-relativeformat.1bebde40ba29c84dc892.chunk.js",
    "880f984518946468822f03464d5256d5ba027398": "/npm.lodash.236696cb50af5a5ffcfd.chunk.js",
    "2c0e079e87de19e2924267177f7f5de948c9f360": "/npm.react-app-polyfill.d83cf03d7d0271d66d4d.chunk.js",
    "337ddbf8007e81fe929d1417afb4180448d89822": "/npm.react-intl.09fde717d9b253bae879.chunk.js",
    "fbef96dc61056888b41209fc25e01e707b9fdd29": "/npm.react-redux.10b7364a3b0289a2c902.chunk.js",
    "a4366b6bbd1e0cf3126171588d534058ce1cec80": "/runtime.00ea1d32e658d9d24a16.js",
    "d37993f10c8a3429385c7adb61887348919ef4b2": "/15.e6e33ae3bb337cc020d1.chunk.js",
    "394d9637c340fc2f62eaab33b5b8fc108fab3867": "/16.0c33da6002ed97f0df45.chunk.js",
    "40da413b90075ffd4ef95139fdb24294cbb74a80": "/17.bfd4b8fad461c2b9f933.chunk.js",
    "6df3daab80eb2fde4f5d2ee02997e13e852854bc": "/18.450f63017db666d0d6d2.chunk.js",
    "15b1c378c22231b50bc6c39996283e80f949b016": "/19.11d29128fb018e743b16.chunk.js",
    "154c5cb2fb50e88f5f1450891658a7356087bcd2": "/20.aa1c29a2208f16af229a.chunk.js",
    "9788ca235b16fc7187261823314331bb4a228bb0": "/21.2c568ec78d475f527827.chunk.js",
    "5ae6519aca7aebfd44d04c2d9de56d7fbb8ed22b": "/22.c841278654d03d8f13f2.chunk.js",
    "ee26041cdf6c1d05b8f0a59711bdb168af178955": "/23.ec45ba762ebe8ac3cfd0.chunk.js",
    "23c4727d850dbf1a72cbef1f4b7ea5d76cdd0615": "/24.d97a13a928829c0e41aa.chunk.js",
    "e92f41b36adac7a4a74a57aca8cd2fa19c30b5c7": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "11/12/2019, 6:30:28 PM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });